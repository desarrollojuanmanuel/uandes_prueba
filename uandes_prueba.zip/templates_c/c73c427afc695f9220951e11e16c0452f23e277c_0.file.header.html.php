<?php
/* Smarty version 3.1.30, created on 2019-08-30 02:25:32
  from "C:\wamp\www\uandes_prueba\templates\header.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5d68891ce81bc4_81332160',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c73c427afc695f9220951e11e16c0452f23e277c' => 
    array (
      0 => 'C:\\wamp\\www\\uandes_prueba\\templates\\header.html',
      1 => 1567117489,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5d68891ce81bc4_81332160 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!doctype html>
<html lang="en-us">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
        <meta http-equiv="X-UA-Compatible" content="IE=Edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        
        <meta name="keywords" content="HTML,CSS,XML,JavaScript">
        <meta name="description" content="Sitio prueba uandes">
        <meta name="author" content="Juan M. Gutierrez">
        <link rel="icon" href="favicon.ico">
        <title>Prueba U. Andes PHP</title>

        <!-- Bootstrap core CSS -->
        <link href="lib/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
        <link href="lib/bootstrap/dist/css/bootstrap-theme.min.css" rel="stylesheet">
        <link href="css/style.css" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Lato" />
        <link rel="canonical" href="https://getbootstrap.com/docs/4.0/components/carousel/">
        <title>Page Title</title>
    </head>
 <body>
<?php }
}
